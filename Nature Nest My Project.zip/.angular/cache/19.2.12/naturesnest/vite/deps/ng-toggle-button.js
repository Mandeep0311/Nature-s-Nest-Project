import {
  NG_VALUE_ACCESSOR
} from "./chunk-MA2RAM4I.js";
import {
  CommonModule,
  NgClass,
  NgIf,
  NgStyle
} from "./chunk-J6GKJUH3.js";
import "./chunk-WPFQYBIS.js";
import {
  Component,
  ElementRef,
  EventEmitter,
  Injectable,
  Input,
  NgModule,
  Output,
  forwardRef,
  setClassMetadata,
  ɵɵNgOnChangesFeature,
  ɵɵProvidersFeature,
  ɵɵadvance,
  ɵɵattribute,
  ɵɵdefineComponent,
  ɵɵdefineInjectable,
  ɵɵdefineInjector,
  ɵɵdefineNgModule,
  ɵɵdirectiveInject,
  ɵɵelement,
  ɵɵelementContainerEnd,
  ɵɵelementContainerStart,
  ɵɵelementEnd,
  ɵɵelementStart,
  ɵɵlistener,
  ɵɵnextContext,
  ɵɵproperty,
  ɵɵpureFunction1,
  ɵɵtemplate,
  ɵɵtext,
  ɵɵtextInterpolate1
} from "./chunk-OFF5SZJQ.js";
import {
  __spreadProps,
  __spreadValues
} from "./chunk-35ENWJA4.js";

// node_modules/ng-toggle-button/fesm2022/ng-toggle-button.mjs
var _c0 = (a0) => ({
  "ng-toggle-focused": a0
});
function NgToggleComponent_ng_container_4_span_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "span", 7);
    ɵɵtext(1);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const ctx_r0 = ɵɵnextContext(2);
    ɵɵproperty("ngStyle", ctx_r0.labelLeftStyle);
    ɵɵadvance();
    ɵɵtextInterpolate1(" ", ctx_r0.labelChecked, " ");
  }
}
function NgToggleComponent_ng_container_4_span_2_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "span", 8);
    ɵɵtext(1);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const ctx_r0 = ɵɵnextContext(2);
    ɵɵproperty("ngStyle", ctx_r0.labelRightStyle);
    ɵɵadvance();
    ɵɵtextInterpolate1(" ", ctx_r0.labelUnchecked, " ");
  }
}
function NgToggleComponent_ng_container_4_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainerStart(0);
    ɵɵtemplate(1, NgToggleComponent_ng_container_4_span_1_Template, 2, 2, "span", 5)(2, NgToggleComponent_ng_container_4_span_2_Template, 2, 2, "span", 6);
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    const ctx_r0 = ɵɵnextContext();
    ɵɵadvance();
    ɵɵproperty("ngIf", ctx_r0.toggled);
    ɵɵadvance();
    ɵɵproperty("ngIf", !ctx_r0.toggled);
  }
}
var NgToggleConfig = class _NgToggleConfig {
  static {
    this.ɵfac = function NgToggleConfig_Factory(__ngFactoryType__) {
      return new (__ngFactoryType__ || _NgToggleConfig)();
    };
  }
  static {
    this.ɵprov = ɵɵdefineInjectable({
      token: _NgToggleConfig,
      factory: _NgToggleConfig.ɵfac,
      providedIn: "root"
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(NgToggleConfig, [{
    type: Injectable,
    args: [{
      providedIn: "root"
    }]
  }], null, null);
})();
var DEFAULT_COLOR_CHECKED = "#0099CC";
var DEFAULT_COLOR_UNCHECKED = "#e0e0e0";
var DEFAULT_LABEL_CHECKED = "";
var DEFAULT_LABEL_UNCHECKED = "";
var DEFAULT_SWITCH_COLOR = "#fff";
var DISABLED_COLOR = "#dbdbdb";
var DISABLED_BUTTON_COLOR = "silver";
var nextUniqueId = 0;
var NgToggleComponent = class _NgToggleComponent {
  constructor(config, _elementRef) {
    this.config = config;
    this._elementRef = _elementRef;
    this.value = this.config.value || true;
    this.name = this.config.name || "";
    this.disabled = this.config.disabled || false;
    this.height = this.config.height || 25;
    this.width = this.config.width || 45;
    this.margin = this.config.margin || 2;
    this.fontSize = this.config.fontSize || void 0;
    this.speed = this.config.speed || 300;
    this.color = this.config.color;
    this.switchColor = this.config.switchColor;
    this.labels = this.config.labels || true;
    this.fontColor = this.config.fontColor || void 0;
    this.values = this.config.values || {
      checked: true,
      unchecked: false
    };
    this.textAlign = this.config.textAlign || {
      checked: "left",
      unchecked: "right"
    };
    this.id = "";
    this.ariaLabel = null;
    this.ariaLabelledby = null;
    this.cssColors = false;
    this.change = new EventEmitter();
    this.valueChange = new EventEmitter();
    this.onChange = (_) => {
    };
    this.onTouch = () => {
    };
    this._uniqueId = "ng-toggle-" + ++nextUniqueId;
    this.id = this.id || this._uniqueId;
    this.ariaLabel = this.ariaLabel || this.name || this.id;
  }
  ngOnInit() {
    this.setToogle();
  }
  onInput(value) {
    this.value = value;
    this.onTouch();
    this.onChange(this.value);
  }
  writeValue(value) {
    this.value = value;
    this.setToogle();
  }
  registerOnChange(fn) {
    this.onChange = fn;
  }
  registerOnTouched(fn) {
    this.onTouch = fn;
  }
  setDisabledState(isDisabled) {
    this.disabled = isDisabled;
  }
  setToogle() {
    const value = this.value;
    let index = Object.values(this.values).findIndex((el) => el == value);
    if (index > -1) this.toggled = Object.keys(this.values)[index] == "checked" ? true : false;
  }
  ngOnChanges(changes) {
    for (const propName in changes) {
      const chng = changes[propName];
      if (propName == "value") this.writeValue(chng.currentValue);
    }
  }
  get coreStyle() {
    return {
      width: px(this.width),
      height: px(this.height),
      transition: `all ${this.speed}ms`,
      backgroundColor: this.cssColors ? null : this.disabled ? this.colorDisabled : this.colorCurrent,
      borderRadius: px(Math.round(this.height / 2))
    };
  }
  get buttonRadius() {
    const radius = this.height - this.margin * 2;
    return radius > 0 ? radius : 0;
  }
  get distance() {
    return px(this.width - this.height + this.margin);
  }
  get buttonStyle() {
    const transition = `all ${this.speed}ms`;
    const margin = px(this.margin);
    const transform = this.toggled ? translate(this.distance, margin) : translate(margin, margin);
    let background = this.switchColor ? this.switchColorCurrent : null;
    background = this.disabled ? this.switchColorDisabled : background;
    return {
      width: px(this.buttonRadius),
      height: px(this.buttonRadius),
      transition,
      transform,
      background
    };
  }
  get labelStyle() {
    return {
      lineHeight: px(this.height),
      fontSize: this.fontSize ? px(this.fontSize) : null,
      color: this.fontColor ? this.fontColorCurrent : null,
      width: px(this.width - this.buttonRadius - this.margin)
    };
  }
  get labelLeftStyle() {
    return __spreadProps(__spreadValues({}, this.labelStyle), {
      textAlign: this.textAlign.checked || this.textAlign
    });
  }
  get labelRightStyle() {
    return __spreadProps(__spreadValues({}, this.labelStyle), {
      textAlign: this.textAlign.unchecked || this.textAlign
    });
  }
  get colorChecked() {
    let {
      color
    } = this;
    if (!isObject(color)) {
      return color || DEFAULT_COLOR_CHECKED;
    }
    return get(color, "checked", DEFAULT_COLOR_CHECKED);
  }
  get colorUnchecked() {
    return get(this.color, "unchecked", DEFAULT_COLOR_UNCHECKED);
  }
  get colorDisabled() {
    return get(this.color, "disabled", DISABLED_COLOR);
  }
  get colorCurrent() {
    return this.toggled ? this.colorChecked : this.colorUnchecked;
  }
  get labelChecked() {
    return get(this.labels, "checked", DEFAULT_LABEL_CHECKED);
  }
  get labelUnchecked() {
    return get(this.labels, "unchecked", DEFAULT_LABEL_UNCHECKED);
  }
  get switchColorChecked() {
    return get(this.switchColor, "checked", DEFAULT_SWITCH_COLOR);
  }
  get switchColorUnchecked() {
    return get(this.switchColor, "unchecked", DEFAULT_SWITCH_COLOR);
  }
  get switchColorDisabled() {
    return get(this.switchColor, "disabled", DISABLED_BUTTON_COLOR);
  }
  get switchColorCurrent() {
    if (!isObject(this.switchColor)) {
      return this.switchColor || DEFAULT_SWITCH_COLOR;
    }
    return this.toggled ? this.switchColorChecked : this.switchColorUnchecked;
  }
  get fontColorChecked() {
    return get(this.fontColor, "checked", DEFAULT_SWITCH_COLOR);
  }
  get fontColorUnchecked() {
    return get(this.fontColor, "unchecked", DEFAULT_SWITCH_COLOR);
  }
  get fontColorDisabled() {
    return get(this.fontColor, "disabled", DEFAULT_SWITCH_COLOR);
  }
  get fontColorCurrent() {
    if (!isObject(this.fontColor)) {
      return this.fontColor || DEFAULT_SWITCH_COLOR;
    }
    if (this.disabled) {
      return this.fontColorDisabled;
    }
    return this.toggled ? this.fontColorChecked : this.fontColorUnchecked;
  }
  get label() {
    if (this.ariaLabelledby) {
      return this.ariaLabelledby;
    }
    return this.ariaLabel ? null : `${this._uniqueId}-label`;
  }
  toggle(event) {
    const toggled = !this.toggled;
    this.toggled = toggled;
    this.value = this.getValue(toggled);
    this.onTouch();
    this.onChange(this.value);
    this.valueChange.emit(this.value);
  }
  getValue(key) {
    return key === true ? this.values["checked"] : this.values["unchecked"];
  }
  onFocus(event) {
    if (!this.focused && event.relatedTarget) {
      this.focused = true;
    }
  }
  onFocusout(event) {
    if (!this._elementRef.nativeElement.contains(event.relatedTarget)) {
      this.focused = false;
      this.onTouch();
    }
  }
  static {
    this.ɵfac = function NgToggleComponent_Factory(__ngFactoryType__) {
      return new (__ngFactoryType__ || _NgToggleComponent)(ɵɵdirectiveInject(NgToggleConfig), ɵɵdirectiveInject(ElementRef));
    };
  }
  static {
    this.ɵcmp = ɵɵdefineComponent({
      type: _NgToggleComponent,
      selectors: [["ng-toggle"]],
      inputs: {
        value: "value",
        name: "name",
        disabled: "disabled",
        height: "height",
        width: "width",
        margin: "margin",
        fontSize: "fontSize",
        speed: "speed",
        color: "color",
        switchColor: "switchColor",
        labels: "labels",
        fontColor: "fontColor",
        values: "values",
        textAlign: "textAlign",
        id: "id",
        ariaLabel: [0, "aria-label", "ariaLabel"],
        ariaLabelledby: [0, "aria-labelledby", "ariaLabelledby"],
        ariaDescribedby: [0, "aria-describedby", "ariaDescribedby"]
      },
      outputs: {
        change: "change",
        valueChange: "valueChange"
      },
      features: [ɵɵProvidersFeature([{
        provide: NG_VALUE_ACCESSOR,
        useExisting: forwardRef(() => _NgToggleComponent),
        multi: true
      }]), ɵɵNgOnChangesFeature],
      decls: 5,
      vars: 16,
      consts: [[1, "ng-toggle-switch", 3, "for"], ["type", "checkbox", "role", "checkbox", 1, "ng-toggle-switch-input", 3, "change", "focusin", "focusout", "checked", "disabled"], [1, "ng-toggle-switch-core", 3, "ngClass", "ngStyle"], [1, "ng-toggle-switch-button", 3, "ngStyle"], [4, "ngIf"], ["class", "ng-toggle-switch-label ng-toggle-left", 3, "ngStyle", 4, "ngIf"], ["class", "ng-toggle-switch-label ng-toggle-right", 3, "ngStyle", 4, "ngIf"], [1, "ng-toggle-switch-label", "ng-toggle-left", 3, "ngStyle"], [1, "ng-toggle-switch-label", "ng-toggle-right", 3, "ngStyle"]],
      template: function NgToggleComponent_Template(rf, ctx) {
        if (rf & 1) {
          ɵɵelementStart(0, "label", 0)(1, "input", 1);
          ɵɵlistener("change", function NgToggleComponent_Template_input_change_1_listener($event) {
            return ctx.toggle($event);
          })("focusin", function NgToggleComponent_Template_input_focusin_1_listener($event) {
            return ctx.onFocus($event);
          })("focusout", function NgToggleComponent_Template_input_focusout_1_listener($event) {
            return ctx.onFocusout($event);
          });
          ɵɵelementEnd();
          ɵɵelementStart(2, "div", 2);
          ɵɵelement(3, "div", 3);
          ɵɵelementEnd();
          ɵɵtemplate(4, NgToggleComponent_ng_container_4_Template, 3, 2, "ng-container", 4);
          ɵɵelementEnd();
        }
        if (rf & 2) {
          ɵɵproperty("for", ctx.id);
          ɵɵattribute("id", ctx.label);
          ɵɵadvance();
          ɵɵproperty("checked", ctx.value)("disabled", ctx.disabled);
          ɵɵattribute("id", ctx.id)("name", ctx.name)("aria-label", ctx.ariaLabel)("aria-labelledby", ctx.label)("aria-describedby", ctx.ariaDescribedby)("aria-checked", ctx.toggled);
          ɵɵadvance();
          ɵɵproperty("ngClass", ɵɵpureFunction1(14, _c0, ctx.focused))("ngStyle", ctx.coreStyle);
          ɵɵadvance();
          ɵɵproperty("ngStyle", ctx.buttonStyle);
          ɵɵadvance();
          ɵɵproperty("ngIf", ctx.labels);
        }
      },
      dependencies: [CommonModule, NgClass, NgIf, NgStyle],
      styles: ["label[_ngcontent-%COMP%]{margin:0;padding:0;border:0;font-size:100%;font:inherit;vertical-align:baseline}.ng-toggle-switch[_ngcontent-%COMP%]{display:inline-block;position:relative;vertical-align:middle;-webkit-user-select:none;user-select:none;font-size:10px;cursor:pointer}.ng-toggle-switch[_ngcontent-%COMP%]   .ng-toggle-switch-input[_ngcontent-%COMP%]{opacity:0;position:absolute;width:1px;height:1px}.ng-toggle-switch[_ngcontent-%COMP%]   .ng-toggle-switch-label[_ngcontent-%COMP%]{position:absolute;top:0;font-weight:600;color:#fff;z-index:1;padding:0 10px;box-sizing:border-box}.ng-toggle-switch[_ngcontent-%COMP%]   .ng-toggle-switch-label.ng-toggle-left[_ngcontent-%COMP%]{left:0}.ng-toggle-switch[_ngcontent-%COMP%]   .ng-toggle-switch-label.ng-toggle-right[_ngcontent-%COMP%]{right:0}.ng-toggle-switch[_ngcontent-%COMP%]   .ng-toggle-switch-core[_ngcontent-%COMP%]{display:block;position:relative;box-sizing:border-box;outline:0;margin:0;transition:border-color .3s,background-color .3s;-webkit-user-select:none;user-select:none}.ng-toggle-switch[_ngcontent-%COMP%]   .ng-toggle-switch-core[_ngcontent-%COMP%]   .ng-toggle-switch-button[_ngcontent-%COMP%]{display:block;position:absolute;overflow:hidden;top:0;left:0;border-radius:100%;background-color:#fff;z-index:2}.ng-toggle-switch.disabled[_ngcontent-%COMP%]{pointer-events:none;opacity:.6}.ng-toggle-focused[_ngcontent-%COMP%]{box-shadow:0 0 4px 3px #999}"]
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(NgToggleComponent, [{
    type: Component,
    args: [{
      selector: "ng-toggle",
      standalone: true,
      imports: [CommonModule],
      providers: [{
        provide: NG_VALUE_ACCESSOR,
        useExisting: forwardRef(() => NgToggleComponent),
        multi: true
      }],
      template: `<label class="ng-toggle-switch" [for]="id" [attr.id]="label">
  <input
    type="checkbox"
    class="ng-toggle-switch-input"
    [checked]="value"
    [disabled]="disabled"
    (change)="toggle($event)"
    (focusin)="onFocus($event)"
    (focusout)="onFocusout($event)"
    [attr.id]="id"
    [attr.name]="name"
    [attr.aria-label]="ariaLabel"
    [attr.aria-labelledby]="label"
    [attr.aria-describedby]="ariaDescribedby"
    [attr.aria-checked]="toggled"
    role="checkbox"
  >
  <div
    class="ng-toggle-switch-core"
    [ngClass]="{'ng-toggle-focused': focused}"
    [ngStyle]="coreStyle"
  >
    <div
      class="ng-toggle-switch-button"
      [ngStyle]="buttonStyle">
    </div>
  </div>
  <ng-container *ngIf="labels">
    <span
      class="ng-toggle-switch-label ng-toggle-left"
      [ngStyle]="labelLeftStyle"
      *ngIf="toggled"
    >
      {{labelChecked}}
    </span>
    <span
      class="ng-toggle-switch-label ng-toggle-right"
      [ngStyle]="labelRightStyle"
      *ngIf="!toggled"
    >
      {{labelUnchecked}}
    </span>
  </ng-container>
</label>`,
      styles: ["label{margin:0;padding:0;border:0;font-size:100%;font:inherit;vertical-align:baseline}.ng-toggle-switch{display:inline-block;position:relative;vertical-align:middle;-webkit-user-select:none;user-select:none;font-size:10px;cursor:pointer}.ng-toggle-switch .ng-toggle-switch-input{opacity:0;position:absolute;width:1px;height:1px}.ng-toggle-switch .ng-toggle-switch-label{position:absolute;top:0;font-weight:600;color:#fff;z-index:1;padding:0 10px;box-sizing:border-box}.ng-toggle-switch .ng-toggle-switch-label.ng-toggle-left{left:0}.ng-toggle-switch .ng-toggle-switch-label.ng-toggle-right{right:0}.ng-toggle-switch .ng-toggle-switch-core{display:block;position:relative;box-sizing:border-box;outline:0;margin:0;transition:border-color .3s,background-color .3s;-webkit-user-select:none;user-select:none}.ng-toggle-switch .ng-toggle-switch-core .ng-toggle-switch-button{display:block;position:absolute;overflow:hidden;top:0;left:0;border-radius:100%;background-color:#fff;z-index:2}.ng-toggle-switch.disabled{pointer-events:none;opacity:.6}.ng-toggle-focused{box-shadow:0 0 4px 3px #999}\n"]
    }]
  }], function() {
    return [{
      type: NgToggleConfig
    }, {
      type: ElementRef
    }];
  }, {
    value: [{
      type: Input
    }],
    name: [{
      type: Input
    }],
    disabled: [{
      type: Input
    }],
    height: [{
      type: Input
    }],
    width: [{
      type: Input
    }],
    margin: [{
      type: Input
    }],
    fontSize: [{
      type: Input
    }],
    speed: [{
      type: Input
    }],
    color: [{
      type: Input
    }],
    switchColor: [{
      type: Input
    }],
    labels: [{
      type: Input
    }],
    fontColor: [{
      type: Input
    }],
    values: [{
      type: Input
    }],
    textAlign: [{
      type: Input
    }],
    id: [{
      type: Input
    }],
    ariaLabel: [{
      type: Input,
      args: ["aria-label"]
    }],
    ariaLabelledby: [{
      type: Input,
      args: ["aria-labelledby"]
    }],
    ariaDescribedby: [{
      type: Input,
      args: ["aria-describedby"]
    }],
    change: [{
      type: Output
    }],
    valueChange: [{
      type: Output
    }]
  });
})();
var isObject = (value) => {
  return typeof value === "object";
};
var has = (object, key) => {
  return isObject(object) && object.hasOwnProperty(key);
};
var get = (object, key, defaultValue) => {
  return has(object, key) ? object[key] : defaultValue;
};
var px = (value) => {
  return `${value}px`;
};
var translate = (x, y) => {
  return `translate(${x}, ${y})`;
};
var NgToggleModule = class _NgToggleModule {
  static forRoot(config = {}) {
    return {
      ngModule: _NgToggleModule,
      providers: [{
        provide: NgToggleConfig,
        useValue: config
      }]
    };
  }
  static {
    this.ɵfac = function NgToggleModule_Factory(__ngFactoryType__) {
      return new (__ngFactoryType__ || _NgToggleModule)();
    };
  }
  static {
    this.ɵmod = ɵɵdefineNgModule({
      type: _NgToggleModule,
      imports: [NgToggleComponent],
      exports: [NgToggleComponent]
    });
  }
  static {
    this.ɵinj = ɵɵdefineInjector({
      providers: [NgToggleConfig],
      imports: [NgToggleComponent]
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(NgToggleModule, [{
    type: NgModule,
    args: [{
      imports: [NgToggleComponent],
      exports: [NgToggleComponent],
      providers: [NgToggleConfig]
    }]
  }], null, null);
})();
export {
  NgToggleComponent,
  NgToggleConfig,
  NgToggleModule,
  get,
  has,
  isObject,
  px,
  translate
};
//# sourceMappingURL=ng-toggle-button.js.map
