import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ArtPiece } from '../../../models/ArtPiece/art-piece.model';
import { ArtpieceService } from '../../../shared/artpiece/artpiece.service';
import { Router } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';
import { ToastrService } from 'ngx-toastr';
import { CloudinaryService } from '../../../shared/cloudinary/cloudinary.service';

@Component({
  selector: 'app-add-artpiece',
  imports: [FormsModule],
  templateUrl: './add-artpiece.component.html',
  styleUrl: './add-artpiece.component.css'
})
export class AddArtpieceComponent {


  artPieceObj: ArtPiece = {}

  constructor(
    private artPieceService: ArtpieceService,
    private router: Router,
    private toastr: ToastrService,
    private spinner: NgxSpinnerService,
    private cloudinaryService: CloudinaryService
  ) { }


  selectedFile: File | null = null;

  uploadFile(event: any) {
    this.selectedFile = event.target.files[0];
  }


  submit() {
    this.spinner.show()
    if (this.selectedFile) {
      this.cloudinaryService.uploadImage(this.selectedFile).subscribe((uploadedRes: any) => {
        this.artPieceObj.imageUrl = uploadedRes.secure_url
        this.artPieceService.add(this.artPieceObj).then((res: any) => {
          this.spinner.hide()
          this.toastr.success("Added Successfully", 'Success')
          this.router.navigateByUrl("/admin/artpieces/manage")
        },
          (err: any) => {
            this.spinner.hide()
            console.log(err, 'Error in add artpiece');
            this.toastr.error("Something Went Wrong", 'Error')
          }
        )
      }, (err: any) => {
        this.spinner.hide()
        console.log(err, 'Error in upload image');
        this.toastr.error("Something Went Wrong", 'Error')
      }
      )
    }
    else {
      this.spinner.hide()
      this.toastr.error("No file selected", "Error");
    }

  }
}
