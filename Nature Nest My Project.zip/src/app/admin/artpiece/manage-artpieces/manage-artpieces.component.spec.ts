import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ManageArtpiecesComponent } from './manage-artpieces.component';

describe('ManageArtpiecesComponent', () => {
  let component: ManageArtpiecesComponent;
  let fixture: ComponentFixture<ManageArtpiecesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ManageArtpiecesComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ManageArtpiecesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
