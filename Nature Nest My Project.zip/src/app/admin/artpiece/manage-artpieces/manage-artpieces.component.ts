import { Component } from '@angular/core';
import { Router, RouterLink } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';
import { ToastrService } from 'ngx-toastr';
import { map } from 'rxjs';
import Swal from 'sweetalert2';
import { ArtpieceService } from '../../../shared/artpiece/artpiece.service';
import { NgToggleModule } from 'ng-toggle-button';

@Component({
  selector: 'app-manage-artpieces',
  imports: [RouterLink, NgToggleModule,],
  templateUrl: './manage-artpieces.component.html',
  styleUrl: './manage-artpieces.component.css'
})
export class ManageArtpiecesComponent {


  artPieces: any;

  constructor(private spinner: NgxSpinnerService, private toastr: ToastrService, private artPieceService: ArtpieceService, private router: Router) {

  }
  ngOnInit(): void {
    this.getAll()
  }



  getAll() {
    this.spinner.show()
    this.artPieceService.getAll().subscribe((data: any) => {
      this.spinner.hide()
      this.artPieces = data;
      this.toastr.success("Success", 'Loaded Successful')
    },
      (err: any) => {
        this.spinner.hide()
        this.toastr.error('Error', err)
        console.log("error is get all artpiecesF", err);
      });
  }


  delete(id: any, status: boolean) {
    const action = status ? "activated" : "deactivated";
    Swal.fire({
      title: `Are you sure you want to ${action} this artpiece?`,
      text: `You can change it again later if needed.`,
      icon: "warning",
      showCancelButton: true,
      confirmButtonColor: "#3085d6",
      cancelButtonColor: "#d33",
      confirmButtonText: `Yes, ${action} it!`
    }).then((result) => {
      if (result.isConfirmed) {
        this.spinner.show();
        const updatedStatus = status;
        this.artPieceService.updateData(id, { status: updatedStatus }).then(
          () => {
            this.spinner.hide();
            Swal.fire({
              title: "Success!",
              text: `The artpiece has been ${updatedStatus ? 'activated' : 'deactivated'} successfully.`,
              icon: "success"
            });
            this.getAll();
          },
          (err) => {
            this.spinner.hide();
             this.getAll()
            this.toastr.error("Something Went Wrong", "Try Again");
            console.log("Error in updating status", err);
          }
        );
      }
      else {
        this.getAll()
      }
    });
  }


}
