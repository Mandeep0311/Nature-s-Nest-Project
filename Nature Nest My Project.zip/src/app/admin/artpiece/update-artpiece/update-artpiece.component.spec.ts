import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UpdateArtpieceComponent } from './update-artpiece.component';

describe('UpdateArtpieceComponent', () => {
  let component: UpdateArtpieceComponent;
  let fixture: ComponentFixture<UpdateArtpieceComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [UpdateArtpieceComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(UpdateArtpieceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
