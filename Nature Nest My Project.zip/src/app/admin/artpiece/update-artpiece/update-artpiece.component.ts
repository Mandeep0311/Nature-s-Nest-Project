import { Component } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';
import { ToastrService } from 'ngx-toastr';
import { ArtPiece } from '../../../models/ArtPiece/art-piece.model';
import { ArtpieceService } from '../../../shared/artpiece/artpiece.service';
import { CloudinaryService } from '../../../shared/cloudinary/cloudinary.service';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-update-artpiece',
  imports: [FormsModule],
  templateUrl: './update-artpiece.component.html',
  styleUrl: './update-artpiece.component.css'
})
export class UpdateArtpieceComponent {

  artPieceObj: ArtPiece = {}

  id: any;

  constructor(private activatedRoute: ActivatedRoute,
    private spinner: NgxSpinnerService,
    private toastr: ToastrService,
    private artPieceService: ArtpieceService,
    private router: Router,
    private cloudinaryService: CloudinaryService
  ) {

  }


  ngOnInit(): void {
    this.id = this.activatedRoute.snapshot.paramMap.get('id')
    this.getSingle()
  }


  getSingle() {
    this.spinner.show()
    this.artPieceService.getSingle(this.id).subscribe((res: any) => {
      this.artPieceObj = res
      this.spinner.hide()
    },
      err => {
        this.spinner.hide()
        console.log(err, 'Error in get single artpiece');
        this.toastr.error("Something Went Wrong", 'Error')
      })

  }

  selectedFile: File | null = null;

  uploadFile(event: any) {
    this.selectedFile = event.target.files[0];
  }

  submit() {
    this.spinner.show()
    if (this.selectedFile) {
      this.cloudinaryService.uploadImage(this.selectedFile).subscribe((uploadedRes: any) => {
        this.artPieceObj.imageUrl = uploadedRes.secure_url
        this.artPieceService.updateData(this.id, this.artPieceObj).then(() => {
          this.spinner.hide()
          this.toastr.success("success", 'artpiece Updated')
          this.router.navigateByUrl("/admin/artpieces/manage")
        },
          (err: any) => {
            this.spinner.hide()
            console.log(err, 'Error in upadte artpiece');
            this.toastr.error("Something Went Wrong", 'Error')

          }
        )
      })
    }
    else {
      this.artPieceService.updateData(this.id, this.artPieceObj).then(() => {
        this.spinner.hide()
        this.toastr.success("success", 'artpiece Updated')
        this.router.navigateByUrl("/admin/artpieces/manage")
      },
        (err: any) => {
          this.spinner.hide()
          console.log(err, 'Error in upadte artpiece');
          this.toastr.error("Something Went Wrong", 'Error')

        }
      )

    }


  }
}
