import { Component } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';
import { ToastrService } from 'ngx-toastr';
import { Booking } from '../../models/Booking/booking.model';
import { BookingService } from '../../shared/booking/booking.service';
import { DesignService } from '../../shared/design/design.service';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-booking-status',
  imports: [FormsModule],
  templateUrl: './booking-status.component.html',
  styleUrl: './booking-status.component.css'
})
export class BookingStatusComponent {

  bookingObj: Booking = {}

  constructor(
    private bookingservice: BookingService,
    private toastr: ToastrService,
    private spinner: NgxSpinnerService,
    private router: Router, private activatedRoute: ActivatedRoute,
    private designService: DesignService
  ) { }


  bookingId: any;

  ngOnInit(): void {
    this.bookingId = this.activatedRoute.snapshot.paramMap.get("id")

  }


  submit() {
    this.bookingObj.status = "Accept"
    this.bookingservice.updateBooking(this.bookingId, this.bookingObj).then(() => {
      this.spinner.hide()
      this.toastr.success("Booking Updated")
      this.router.navigateByUrl('/admin/bookings')
    },
      (err: any) => {
        this.spinner.hide()
        this.toastr.error("Something Went Wrong")
        console.log("Error in update  image", err);
      });
  }

}
