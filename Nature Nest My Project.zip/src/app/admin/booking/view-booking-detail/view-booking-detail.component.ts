import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';
import { ToastrService } from 'ngx-toastr';
import { Booking } from '../../../models/Booking/booking.model';
import { BookingService } from '../../../shared/booking/booking.service';
import { CloudinaryService } from '../../../shared/cloudinary/cloudinary.service';

@Component({
  selector: 'app-view-booking-detail',
  imports: [FormsModule],
  templateUrl: './view-booking-detail.component.html',
  styleUrl: './view-booking-detail.component.css'
})
export class UploadFinalImageComponent {

  bookingObj: Booking = {}

  constructor(
    private bookingService: BookingService,
    private toastr: ToastrService,
    private spinner: NgxSpinnerService,
    private router: Router,
    private activatedRoute: ActivatedRoute,
    private cloudinaryService: CloudinaryService,

  ) { }


  bookingId: any
  ngOnInit(): void {
    this.bookingId = this.activatedRoute.snapshot.paramMap.get("id");
    this.bookingObj.id = this.bookingId

  }


  selectedFile: File | null = null;

  uploadFile(event: any) {
    this.selectedFile = event.target.files[0];
  }


  submit() {
    this.spinner.show()
    if (this.selectedFile) {
      this.cloudinaryService.uploadImage(this.selectedFile).subscribe((uploadedRes: any) => {
        this.bookingObj.status = "Completed"
        this.bookingObj.finalImage = uploadedRes.secure_url
        this.bookingService.updateBooking(this.bookingId, this.bookingObj).then(() => {
          this.spinner.hide()
          this.toastr.success("success", 'Updated Successful')
          this.router.navigateByUrl("/admin/bookings")
        },
          (err: any) => {
            this.spinner.hide()
            console.log(err, 'Error in upadte booking');
            this.toastr.error("Something Went Wrong", 'Error')
          }
        )
      })
    }
    else {
      delete this.bookingObj.finalImage
      this.bookingService.updateBooking(this.bookingId, this.bookingObj).then(() => {
        this.spinner.hide()
        this.toastr.success("success", 'Updated Successful')
        this.router.navigateByUrl("/admin/bookings")
      },
        (err: any) => {
          this.spinner.hide()
          console.log(err, 'Error in upadte booking');
          this.toastr.error("Something Went Wrong", 'Error')

        }
      )
    }
  }

}
