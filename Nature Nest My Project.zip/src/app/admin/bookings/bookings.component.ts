import { DatePipe } from '@angular/common';
import { Component } from '@angular/core';
import { NgxSpinnerService } from 'ngx-spinner';
import { ToastrService } from 'ngx-toastr';
import { map } from 'rxjs';
import Swal from 'sweetalert2';
import { Postedwork } from '../../models/Postedwork/postedwork.model';
import { BookingService } from '../../shared/booking/booking.service';
import { PostService } from '../../shared/post/post.service';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-bookings',
  imports: [DatePipe, RouterLink],
  templateUrl: './bookings.component.html',
  styleUrl: './bookings.component.css'
})
export class BookingsComponent {

  constructor(
    private spinner: NgxSpinnerService,
    private toastr: ToastrService,
    private bookingService: BookingService,
    private postService: PostService
  ) {

  }





  ngOnInit(): void {
    this.allBookings()
    this.allPosts()
  }

  bookings: any;

  allBookings() {
    this.spinner.show()
    this.bookingService.getAll().subscribe((data: any) => {
      this.spinner.hide()
      this.bookings = data;
      this.toastr.success("Success", 'Loaded Successful')
    },
      (err: any) => {
        this.spinner.hide()
        this.toastr.error('Error', err)
        console.log("error is get all bookings", err);
      });
  }


  Posts: any;


  allPosts() {
    this.spinner.show()
    this.postService.getAll().subscribe((data: any) => {
      this.spinner.hide()
      this.Posts = data;

    },
      (err: any) => {
        this.spinner.hide()
        this.toastr.error('Error', err)
        console.log("error is get all bookings", err);
      });
  }


  postObj: Postedwork = {};

  uploadPost(data: any) {
    this.spinner.show();
    this.postObj.cost = data.cost;
    this.postObj.finalProductImageUrl = data.finalImage;
    this.postObj.review = data.review;
    this.postObj.userName = data.userName;
    this.postObj.userProfile = data.userProfile;
    this.postObj.bookingId = data.bookingId;
    this.postService.add(this.postObj).then(
      () => {
        this.spinner.hide();
        this.bookingService.updateBooking(data.bookingId, { postAdded: true })
        this.toastr.success("Your post has been successfully uploaded!");
        this.allBookings();
      },
      (err) => {
        this.spinner.hide();
        this.toastr.error("Something went wrong while uploading the post.");
        console.error("Error in uploading post", err);
      }
    );
  }



  delete(id: any, status: any) {
    Swal.fire({
      title: "Are you sure?",
      text: "This booking will be declined and cannot be undone!",
      icon: "warning",
      showCancelButton: true,
      confirmButtonColor: "#3085d6",
      cancelButtonColor: "#d33",
      confirmButtonText: "Yes, decline it!"
    }).then((result) => {
      if (result.isConfirmed) {
        this.spinner.show();
        this.bookingService.updateBooking(id, { status: 'declined' }).then(
          () => {
            this.spinner.hide();
            Swal.fire({
              title: "Declined!",
              text: "The booking has been successfully declined.",
              icon: "success"
            });
            this.allBookings();
          },
          (err) => {
            this.spinner.hide();
            this.toastr.error("Something Went Wrong", "Try Again");
            console.log("Error in declining booking", err);
          }
        );
      }
    });

  }

}
