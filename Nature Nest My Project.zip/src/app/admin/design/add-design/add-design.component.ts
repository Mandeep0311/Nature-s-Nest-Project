import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';
import { ToastrService } from 'ngx-toastr';
import { Designs } from '../../../models/Designs/designs.model';
import { CloudinaryService } from '../../../shared/cloudinary/cloudinary.service';
import { ArtpieceService } from '../../../shared/artpiece/artpiece.service';
import { DesignService } from '../../../shared/design/design.service';

@Component({
  selector: 'app-add-design',
  imports: [FormsModule],
  templateUrl: './add-design.component.html',
  styleUrl: './add-design.component.css'
})
export class AddDesignComponent {


  designObj: Designs = {}

  constructor(
    private designService: DesignService,
    private artpieceService: ArtpieceService,
    private router: Router,
    private toastr: ToastrService,
    private spinner: NgxSpinnerService,
    private cloudinaryService: CloudinaryService
  ) { }


  ngOnInit(): void {
    this.allArtpieces()
  }

  selectedFile: File | null = null;

  uploadFile(event: any) {
    this.selectedFile = event.target.files[0];
  }

  artpieces: any[] = []


  allArtpieces() {
    this.artpieceService.getAll().subscribe((data: any) => {
      this.artpieces = data;
    },
      (err: any) => {
        this.spinner.hide()
        this.toastr.error('Error', err)
      });
  }

  selectCat(event: any) {
    let id = event.target.value;
    let name = this.artpieces.filter((x) => { return x.id == id })[0].name
    this.designObj.artPieceName = name
  }

  submit() {
    this.spinner.show()
    if (this.selectedFile) {
      this.cloudinaryService.uploadImage(this.selectedFile).subscribe((uploadedRes: any) => {
        this.designObj.imageUrl = uploadedRes.secure_url
        this.designService.add(this.designObj).then((res: any) => {
          this.spinner.hide()
          this.toastr.success("design Added Successfully", 'Success')
          this.router.navigateByUrl("/admin/designs/manage")
        },
          (err: any) => {
            this.spinner.hide()
            console.log(err, 'Error in add design');
            this.toastr.error("Something Went Wrong", 'Error')
          }
        )
      }, (err: any) => {
        this.spinner.hide()
        console.log(err, 'Error in upload image');
        this.toastr.error("Something Went Wrong", 'Error')
      }
      )
    }
    else {
      this.spinner.hide()
      this.toastr.error("No file selected", "Error");
    }

  }
}
