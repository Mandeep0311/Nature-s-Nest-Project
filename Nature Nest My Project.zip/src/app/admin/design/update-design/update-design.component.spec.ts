import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UpdateDesignComponent } from './update-design.component';

describe('UpdateDesignComponent', () => {
  let component: UpdateDesignComponent;
  let fixture: ComponentFixture<UpdateDesignComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [UpdateDesignComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(UpdateDesignComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
