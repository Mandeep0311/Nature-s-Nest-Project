import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';
import { ToastrService } from 'ngx-toastr';
import { Designs } from '../../../models/Designs/designs.model';
import { ArtpieceService } from '../../../shared/artpiece/artpiece.service';
import { CloudinaryService } from '../../../shared/cloudinary/cloudinary.service';
import { DesignService } from '../../../shared/design/design.service';

@Component({
  selector: 'app-update-design',
  imports: [FormsModule],
  templateUrl: './update-design.component.html',
  styleUrl: './update-design.component.css'
})
export class UpdateDesignComponent {


  designObj: Designs = {}

  constructor(
    private designService: DesignService,
    private artpieceService: ArtpieceService,
    private router: Router,
    private toastr: ToastrService,
    private spinner: NgxSpinnerService,
    private cloudinaryService: CloudinaryService,
    private activatedRoute: ActivatedRoute,
  ) { }

  id: any;

  ngOnInit(): void {
    this.id = this.activatedRoute.snapshot.paramMap.get('id')
    this.allArtpieces()
    this.getSingleDesign()

  }


  getSingleDesign() {
    this.designService.getSingle(this.id).subscribe((res: any) => {
      this.designObj = res
    },
      err => {
        this.spinner.hide()
        console.log(err, 'Error in get single design');
        this.toastr.error("Something Went Wrong", 'Error')
      })

  }

  selectedFile: File | null = null;

  uploadFile(event: any) {
    this.selectedFile = event.target.files[0];
  }

  artpieces: any[] = []


  allArtpieces() {
    this.artpieceService.getAll().subscribe((data: any) => {
      this.artpieces = data;
    },
      (err: any) => {
        this.spinner.hide()
        this.toastr.error('Error', err)
      });
  }




  selectCat(event: any) {
    let id = event.target.value;
    let name = this.artpieces.filter((x) => { return x.id == id })[0].name
    this.designObj.artPieceName = name
  }


  submit() {
    this.spinner.show()
    if (this.selectedFile) {
      this.cloudinaryService.uploadImage(this.selectedFile).subscribe((uploadedRes: any) => {
        this.designObj.imageUrl = uploadedRes.secure_url
        this.designService.updateData(this.id, this.designObj).then(() => {
          this.spinner.hide()
          this.toastr.success("success", 'Design Updated')
          this.router.navigateByUrl("/admin/designs/manage")
        },
          (err: any) => {
            this.spinner.hide()
            console.log(err, 'Error in upadte Design');
            this.toastr.error("Something Went Wrong", 'Error')
          }
        )
      })
    }
    else {
      this.designService.updateData(this.id, this.designObj).then(() => {
        this.spinner.hide()
        this.toastr.success("success", 'Design Updated')
        this.router.navigateByUrl("/admin/designs/manage")
      },
        (err: any) => {
          this.spinner.hide()
          console.log(err, 'Error in upadte Design');
          this.toastr.error("Something Went Wrong", 'Error')

        }
      )
    }
  }
}
