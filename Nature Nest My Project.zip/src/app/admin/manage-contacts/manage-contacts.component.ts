import { Component } from '@angular/core';
import { NgxSpinnerService } from 'ngx-spinner';
import { ToastrService } from 'ngx-toastr';
import { ContactService } from '../../shared/contact/contact.service';
import { DatePipe } from '@angular/common';

@Component({
  selector: 'app-manage-contacts',
  imports: [DatePipe],
  templateUrl: './manage-contacts.component.html',
  styleUrl: './manage-contacts.component.css'
})
export class ManageContactsComponent {

  ngOnInit(): void {
    this.allContacts()
  }

  constructor(
    private contactService: ContactService,
    private toastr: ToastrService,
    private spinner: NgxSpinnerService
  ) {

  }



  contacts: any[] = []

  allContacts() {
    this.spinner.show()
    this.contactService.getAll().subscribe((data: any) => {
      this.spinner.hide()
      this.contacts = data;
    },
      (err: any) => {
        this.spinner.hide()
        this.toastr.error('Error', err)
        console.log("error is get all contacts", err);
      });
  }

}
