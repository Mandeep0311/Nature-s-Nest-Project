import { Component } from '@angular/core';
import { NgxSpinnerService } from 'ngx-spinner';
import { ToastrService } from 'ngx-toastr';
import { UserService } from '../../shared/user/user.service';

@Component({
  selector: 'app-manage-customers',
  imports: [],
  templateUrl: './manage-customers.component.html',
  styleUrl: './manage-customers.component.css'
})
export class ManageCustomersComponent {

  constructor(private spinner: NgxSpinnerService, private toastr: ToastrService, private userService: UserService) {

  }
  ngOnInit(): void {
    this.allCustomers()
  }

  customers: any[] = [];

  allCustomers() {
    this.spinner.show()
    this.userService.getAll().subscribe((data: any) => {
      this.spinner.hide()
      this.customers = data;
      this.toastr.success("Success", 'Loaded Successful')
    },
      (err: any) => {
        this.spinner.hide()
        this.toastr.error('Error', err)
        console.log("error is get all designs", err);
      });
  }



  delete(id: any, status: any) {
    this.spinner.show()
    this.userService.updateData(id, { status: status }).then(
      () => {
        this.spinner.hide()
        this.toastr.success("Status Updated", "Success")
        this.allCustomers()
      },
      (err) => {
        this.spinner.hide()
        this.toastr.error("Something Went Wrong", "Try Again")
        console.log("Error In deleting city", err);
      }
    )
  }
}
