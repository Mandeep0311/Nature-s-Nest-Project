import { Component } from '@angular/core';
import { NgxSpinnerService } from 'ngx-spinner';
import { ToastrService } from 'ngx-toastr';
import { map } from 'rxjs';
import { PostService } from '../../shared/post/post.service';
import { DatePipe } from '@angular/common';

@Component({
  selector: 'app-manage-posts',
  imports: [DatePipe],
  templateUrl: './manage-posts.component.html',
  styleUrl: './manage-posts.component.css'
})
export class ManagePostsComponent {


  constructor(private spinner: NgxSpinnerService, private toastr: ToastrService, private postService: PostService) {

  }
  ngOnInit(): void {
    this.allPosts()
  }


  Posts: any;
  allPosts() {
    this.spinner.show()
    this.postService.getAll().subscribe((data: any) => {
      this.spinner.hide()
      this.Posts = data;
      this.toastr.success("Success", 'Loaded Successful')
    },
      (err: any) => {
        this.spinner.hide()
        this.toastr.error('Error', err)
        console.log("error is get all posts", err);
      });
  }

}
