import { Routes } from '@angular/router';
import { LayoutComponent } from './customer/layout/layout.component';
import { HomeComponent } from './customer/home/home.component';
import { AboutComponent } from './customer/about/about.component';
import { AdminLayoutComponent } from './admin/admin-layout/admin-layout.component';
import { DashboardComponent } from './admin/dashboard/dashboard.component';
import { AddArtpieceComponent } from './admin/artpiece/add-artpiece/add-artpiece.component';
import { ManageArtpiecesComponent } from './admin/artpiece/manage-artpieces/manage-artpieces.component';
import { UpdateArtpieceComponent } from './admin/artpiece/update-artpiece/update-artpiece.component';
import { AddDesignComponent } from './admin/design/add-design/add-design.component';
import { ManageDesignsComponent } from './admin/design/manage-designs/manage-designs.component';
import { UpdateDesignComponent } from './admin/design/update-design/update-design.component';
import { ManagePostsComponent } from './admin/manage-posts/manage-posts.component';
import { BookingsComponent } from './admin/bookings/bookings.component';
import { ViewArtpiecesComponent } from './customer/view-artpieces/view-artpieces.component';
import { DesignByArtpiecesComponent } from './customer/design-by-artpieces/design-by-artpieces.component';
import { ViewDesignsComponent } from './customer/view-designs/view-designs.component';
import { ProfileComponent } from './customer/profile/profile.component';
import { BookDesignComponent } from './customer/book-design/book-design.component';
import { RegisterComponent } from './auth/register/register.component';
import { LoginComponent } from './auth/login/login.component';
import { MyBookingsComponent } from './customer/my-bookings/my-bookings.component';
import { BookingStatusComponent } from './admin/booking-status/booking-status.component';
import { UploadFinalImageComponent } from './admin/booking/view-booking-detail/view-booking-detail.component';
import { ManageCustomersComponent } from './admin/manage-customers/manage-customers.component';
import { ContactComponent } from './customer/contact/contact.component';
import { ManageContactsComponent } from './admin/manage-contacts/manage-contacts.component';
import { userGuard } from './guard/user/user.guard';
import { ViewPostsComponent } from './customer/view-posts/view-posts.component';
import { ViewpostComponent } from './customer/viewpost/viewpost.component';

export const routes: Routes = [
    {
        path: '', redirectTo: '/home', pathMatch: 'full'
    },
    {
        path: 'admin', redirectTo: '/admin/dashboard', pathMatch: 'full'
    },
    {
        path: '', component: LayoutComponent, children: [
            {
                path: 'home', component: HomeComponent
            },
            {
                path: 'login', component: LoginComponent
            },
            {
                path: 'register', component: RegisterComponent
            },
            {
                path: 'about', component: AboutComponent
            },
            {
                path: 'contact', component: ContactComponent
            },
            {
                path: 'artpieces', component: ViewArtpiecesComponent
            },
            {
                path: 'designs/viewByArtpieces/:id', component: DesignByArtpiecesComponent
            },
            {
                path: 'designs', component: ViewDesignsComponent
            },
            {
                path: 'profile', component: ProfileComponent, canActivate: [userGuard]
            },
            {
                path: 'design/book/:designId', component: BookDesignComponent, canActivate: [userGuard]
            },
            {
                path: 'bookings', component: MyBookingsComponent, canActivate: [userGuard]
            },
            {
                path: 'post', component: ViewpostComponent, canActivate: [userGuard]
            },
        ]
    },


    {
        path: 'admin', component: AdminLayoutComponent, canActivate: [userGuard], children: [
            {
                path: 'dashboard', component: DashboardComponent
            },

            {
                path: 'artpiece/add', component: AddArtpieceComponent
            },
            {
                path: 'artpieces/manage', component: ManageArtpiecesComponent
            },
            {
                path: 'artpiece/update/:id', component: UpdateArtpieceComponent
            },

            {
                path: 'design/add', component: AddDesignComponent
            },
            {
                path: 'designs/manage', component: ManageDesignsComponent
            },
            {
                path: 'design/update/:id', component: UpdateDesignComponent
            },
            {
                path: 'posts/manage', component: ManagePostsComponent
            },

            {
                path: 'bookings', component: BookingsComponent
            },
            {
                path: 'users', component: ManageCustomersComponent
            },

            {
                path: 'booking/status/:id', component: BookingStatusComponent
            },

            {
                path: 'booking/final-image/:id', component: UploadFinalImageComponent
            },
            {
                path: 'contacts', component: ManageContactsComponent
            }



        ]
    }


];
