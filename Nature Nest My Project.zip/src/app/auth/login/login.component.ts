import { Component } from '@angular/core';
import { NgxSpinnerService } from 'ngx-spinner';
import { UserService } from '../../shared/user/user.service';
import { FormsModule } from '@angular/forms';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-login',
  imports: [FormsModule, RouterLink],
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent {

  email: string = ''
  password: string = ''


  constructor(private userService: UserService, private spinner: NgxSpinnerService) {
  }




  submit() {
    this.spinner.show()
    this.userService.login(this.email, this.password)
  }

}
