import { Component } from '@angular/core';
import { NgxSpinnerService } from 'ngx-spinner';
import { UserService } from '../../shared/user/user.service';
import { User } from '../../models/user/user.model';
import { FormsModule } from '@angular/forms';
import { RouterLink } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { CloudinaryService } from '../../shared/cloudinary/cloudinary.service';

@Component({
  selector: 'app-register',
  imports: [FormsModule, RouterLink],
  templateUrl: './register.component.html',
  styleUrl: './register.component.css'
})
export class RegisterComponent {

  userObj: User = {}

  constructor(
    private userService: UserService,
    private spinner: NgxSpinnerService,
    private toastr: ToastrService,
    private cloudinaryService: CloudinaryService
  ) { }


  selectedFile: File | null = null;

  uploadFile(event: any) {
    this.selectedFile = event.target.files[0];
  }


  register() {
    this.spinner.show()
    if (this.selectedFile) {
      this.cloudinaryService.uploadImage(this.selectedFile).subscribe((uploadedRes: any) => {
        this.userObj.imageUrl = uploadedRes.secure_url
        this.userService.register(this.userObj)
      }, (err: any) => {
        this.spinner.hide()
        console.log(err, 'Error in upload image');
        this.toastr.error("Something Went Wrong", 'Error')
      }
      )
    }
    else {
      this.spinner.hide()
      this.toastr.error("No file selected", "Error");
    }
  }
}
