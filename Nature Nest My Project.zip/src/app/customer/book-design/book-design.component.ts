import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';
import { ToastrService } from 'ngx-toastr';
import { Booking } from '../../models/Booking/booking.model';
import { BookingService } from '../../shared/booking/booking.service';
import { DesignService } from '../../shared/design/design.service';
import { UserService } from '../../shared/user/user.service';

@Component({
  selector: 'app-book-design',
  imports: [FormsModule],
  templateUrl: './book-design.component.html',
  styleUrl: './book-design.component.css'
})
export class BookDesignComponent {


  bookingObj: Booking = {}

  constructor(private bookingservice: BookingService, private toastr: ToastrService, private spinner: NgxSpinnerService, private router: Router, private activatedRoute: ActivatedRoute, private designService: DesignService, private userService: UserService) { }


  designId: any;

  ngOnInit(): void {
    this.designId = this.activatedRoute.snapshot.paramMap.get("designId")
    this.getSingleDesign(this.designId)
  }

  paintingData: any;

  getSingleDesign(id: any) {
    this.designService.getSingle(id).subscribe(
      (res: any) => {
        this.spinner.hide()
        this.paintingData = res
        this.bookingObj.artPieceName = res.artPieceName
        this.bookingObj.designName = res.name
        this.bookingObj.designId = id
      },
      (err) => {
        this.spinner.hide()
        this.toastr.error("Something Went Wrong", "Try Again")
        console.log("Error in Single Job", err);
      }
    )
  }



  submit() {
    this.spinner.show()
    this.bookingObj.userId = sessionStorage.getItem('uid') ?? undefined
    this.userService.getSingle(sessionStorage.getItem('uid') ?? '').subscribe(
      (data: any) => {
        this.spinner.hide()
        this.bookingObj.userName = data.name
        this.bookingObj.userEmail = data.email
        this.bookingObj.finalImage = ''
        this.bookingObj.userProfile = data.imageUrl
        this.bookingObj.postAdded = false
        this.bookingservice.add(this.bookingObj).then((res: any) => {
          this.spinner.hide()
          this.toastr.success("Booking Added Successfully ")
          this.router.navigateByUrl('/bookings')
        },
          (err: any) => {
            this.spinner.hide()
            console.log(err, 'Error in add design');
            this.toastr.error("Something Went Wrong", 'Error')
          }
        )
      },
      (err) => {
        this.spinner.hide()
        this.toastr.error("Something Went Wrong")
        console.log("Error in getting user", err);
      }
    )
  }
}
