import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DesignByArtpiecesComponent } from './design-by-artpieces.component';

describe('DesignByArtpiecesComponent', () => {
  let component: DesignByArtpiecesComponent;
  let fixture: ComponentFixture<DesignByArtpiecesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [DesignByArtpiecesComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(DesignByArtpiecesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
