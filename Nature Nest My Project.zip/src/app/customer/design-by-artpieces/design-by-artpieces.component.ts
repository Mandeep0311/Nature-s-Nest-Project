import { Component } from '@angular/core';
import { Router, ActivatedRoute, RouterLink } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';
import { ToastrService } from 'ngx-toastr';
import { map } from 'rxjs';
import { DesignService } from '../../shared/design/design.service';

@Component({
  selector: 'app-design-by-artpieces',
  imports: [RouterLink],
  templateUrl: './design-by-artpieces.component.html',
  styleUrl: './design-by-artpieces.component.css'
})
export class DesignByArtpiecesComponent {

  designs: any;

  constructor(private spinner: NgxSpinnerService, private toastr: ToastrService, private designService: DesignService, private router: Router, private activatedRoute: ActivatedRoute) {

  }
  ngOnInit(): void {
    this.alldesigns()
  }



  alldesigns() {
    this.spinner.show()
    let id = this.activatedRoute.snapshot.paramMap.get("id")
    this.designService.getAllByArtpieces(id).subscribe((data: any) => {
      this.spinner.hide()
      this.designs = data;
      this.toastr.success("Success", 'Loaded Successful')
    },
      (err: any) => {
        this.spinner.hide()
        this.toastr.error('Error', err)
        console.log("error is get all designs", err);
      });

  }



}
