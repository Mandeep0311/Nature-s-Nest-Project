import { CurrencyPipe, DatePipe } from '@angular/common';
import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { NgxSpinnerService } from 'ngx-spinner';
import { ToastrService } from 'ngx-toastr';
import { map } from 'rxjs';
import { Booking } from '../../models/Booking/booking.model';
import { BookingService } from '../../shared/booking/booking.service';
declare var bootstrap: any;

@Component({
  selector: 'app-my-bookings',
  imports: [CurrencyPipe, DatePipe, FormsModule],
  templateUrl: './my-bookings.component.html',
  styleUrl: './my-bookings.component.css'
})
export class MyBookingsComponent {

  constructor(private spinner: NgxSpinnerService, private toastr: ToastrService, private bookingService: BookingService) {

  }
  ngOnInit(): void {
    this.allBookings()
  }

  bookings: any;

  allBookings() {
    this.spinner.show()
    this.bookingService.myBookings().subscribe((data: any) => {
      this.spinner.hide()
      this.bookings = data;
      this.toastr.success("Success", 'Loaded Successful')
    },
      (err: any) => {
        this.spinner.hide()
        this.toastr.error('Error', err)
        console.log("error is get all artpiecesF", err);
      });
  }


  bookingId: any


  openModel(bookingid: any) {
    this.bookingId = bookingid
  }



  bookingObj: Booking = {}


  addReview() {
    this.bookingService.updateBooking(this.bookingId, this.bookingObj).then(() => {
      this.spinner.hide()
      this.toastr.success("Review Added")
      const modalElement = document.getElementById('addReviewModel');
      if (modalElement) {
        const modalInstance = bootstrap.Modal.getInstance(modalElement);
        modalInstance?.hide();
      }
    },
      (err: any) => {
        this.spinner.hide()
        this.toastr.error("Something Went Wrong")
        console.log("Error in add review", err);
      });

  }



}
