import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';
import { ToastrService } from 'ngx-toastr';
import { UserService } from '../../shared/user/user.service';
import { User } from '../../models/user/user.model';
import { CloudinaryService } from '../../shared/cloudinary/cloudinary.service';

@Component({
  selector: 'app-profile',
  imports: [FormsModule, RouterLink],
  templateUrl: './profile.component.html',
  styleUrl: './profile.component.css'
})
export class ProfileComponent {

  constructor(
    private userService: UserService,
    private toastr: ToastrService,
    private spinner: NgxSpinnerService,
    private router: Router,
    private activatedRoute: ActivatedRoute,
    private cloudinaryService: CloudinaryService,

  ) {
  }

  customerObj: User = {}
  customerId: any
  selectedFile: File | null = null;



  ngOnInit(): void {
    this.customerId = sessionStorage.getItem('uid')
    this.getCustomerData(this.customerId)
  }

  getCustomerData(id: any) {
    this.spinner.show()
    this.userService.getSingle(id).subscribe(
      (res: any) => {
        this.spinner.hide()
        this.customerObj = res
        this.customerObj.id = this.customerId
      },
      (err) => {
        this.spinner.hide()
        this.toastr.error("Something Went Wrong")
        console.log("Error in getting city", err);
      }
    )
  }


  uploadFile(event: any) {
    this.selectedFile = event.target.files[0];
  }


  submit() {
    this.spinner.show()
    if (this.selectedFile) {
      this.cloudinaryService.uploadImage(this.selectedFile).subscribe((uploadedRes: any) => {
        this.customerObj.imageUrl = uploadedRes.secure_url
        this.userService.updateData(this.customerId, this.customerObj).then(() => {
          this.spinner.hide()
          this.toastr.success("success", 'profile Updated')
        },
          (err: any) => {
            this.spinner.hide()
            console.log(err, 'Error in upadte profile');
            this.toastr.error("Something Went Wrong", 'Error')

          }
        )
      })
    }
    else {
      this.userService.updateData(this.customerId, this.customerObj).then(() => {
        this.spinner.hide()
        this.toastr.success("success", 'profile Updated')
      },
        (err: any) => {
          this.spinner.hide()
          console.log(err, 'Error in upadte profile');
          this.toastr.error("Something Went Wrong", 'Error')

        }
      )

    }

  }




}
