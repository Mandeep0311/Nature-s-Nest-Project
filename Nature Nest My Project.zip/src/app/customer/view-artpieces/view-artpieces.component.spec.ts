import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewArtpiecesComponent } from './view-artpieces.component';

describe('ViewArtpiecesComponent', () => {
  let component: ViewArtpiecesComponent;
  let fixture: ComponentFixture<ViewArtpiecesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ViewArtpiecesComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ViewArtpiecesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
