import { Component } from '@angular/core';
import { Router, RouterLink } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';
import { ToastrService } from 'ngx-toastr';
import { map } from 'rxjs';
import { ArtpieceService } from '../../shared/artpiece/artpiece.service';

@Component({
  selector: 'app-view-artpieces',
  imports: [RouterLink],
  templateUrl: './view-artpieces.component.html',
  styleUrl: './view-artpieces.component.css'
})
export class ViewArtpiecesComponent {

  artPieces: any;

  constructor(private spinner: NgxSpinnerService, private toastr: ToastrService, private artPieceService: ArtpieceService, private router: Router) {

  }
  ngOnInit(): void {
    this.getAll()
  }



  getAll() {
    this.spinner.show()
    this.artPieceService.viewArtpieces().subscribe((data: any) => {
      this.spinner.hide()
      this.artPieces = data;
      this.toastr.success("Success", 'Loaded Successful')
    },
      (err: any) => {
        this.spinner.hide()
        this.toastr.error('Error', err)
        console.log("error is get all artpiecesF", err);
      });
  }

}
