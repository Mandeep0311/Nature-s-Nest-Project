import { Component } from '@angular/core';
import { Router, RouterLink } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';
import { ToastrService } from 'ngx-toastr';
import { map } from 'rxjs';
import { DesignService } from '../../shared/design/design.service';

@Component({
  selector: 'app-view-designs',
  imports: [RouterLink],
  templateUrl: './view-designs.component.html',
  styleUrl: './view-designs.component.css'
})
export class ViewDesignsComponent {


  designs: any;

  constructor(private spinner: NgxSpinnerService, private toastr: ToastrService, private designService: DesignService, private router: Router) {

  }
  ngOnInit(): void {
    this.alldesigns()
  }



  alldesigns() {

    this.spinner.show()
    this.designService.viewDesigns().subscribe((data: any) => {
      this.spinner.hide()
      this.designs = data;
      this.toastr.success("Success", 'Loaded Successful')
    },
      (err: any) => {
        this.spinner.hide()
        this.toastr.error('Error', err)
        console.log("error is get all designs", err);
      });



  }

}
