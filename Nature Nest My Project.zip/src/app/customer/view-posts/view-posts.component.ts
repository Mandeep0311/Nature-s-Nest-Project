import { Component } from '@angular/core';

@Component({
  selector: 'app-view-posts',
  imports: [],
  templateUrl: './view-posts.component.html',
  styleUrl: './view-posts.component.css'
})
export class ViewPostsComponent {

}
