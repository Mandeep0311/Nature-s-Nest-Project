import { DatePipe } from '@angular/common';
import { Component } from '@angular/core';
import { NgxSpinnerService } from 'ngx-spinner';
import { ToastrService } from 'ngx-toastr';
import { PostService } from '../../shared/post/post.service';

@Component({
  selector: 'app-viewpost',
  imports: [DatePipe],
  templateUrl: './viewpost.component.html',
  styleUrl: './viewpost.component.css'
})
export class ViewpostComponent {


  constructor(private spinner: NgxSpinnerService, private toastr: ToastrService, private postService: PostService) {

  }
  ngOnInit(): void {
    this.allPosts()
  }


  Posts: any;
  allPosts() {
    this.spinner.show()
    this.postService.getAll().subscribe((data: any) => {
      this.spinner.hide()
      this.Posts = data;
      this.toastr.success("Success", 'Loaded Successful')
    },
      (err: any) => {
        this.spinner.hide()
        this.toastr.error('Error', err)
        console.log("error is get all posts", err);
      });
  }

}