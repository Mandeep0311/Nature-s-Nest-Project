import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';

export const userGuard: CanActivateFn = (route, state) => {

  const router = inject(Router)
  const toastr = inject(ToastrService)

  if (sessionStorage.getItem("uid") == null) {
    toastr.info("Please log in to continue.", "Access Denied");
    router.navigateByUrl("/login")
    return false;
  }
  else {
    return true;
  }


};
