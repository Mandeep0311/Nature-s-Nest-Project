import { ArtPiece } from './art-piece.model';

describe('ArtPiece', () => {
  it('should create an instance', () => {
    expect(new ArtPiece()).toBeTruthy();
  });
});
