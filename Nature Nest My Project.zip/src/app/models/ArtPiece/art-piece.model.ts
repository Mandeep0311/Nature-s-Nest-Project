export class ArtPiece {
    id?: string;
    name?: string;
    description?: string;
    imageUrl?: string;
    createdAt?: number;
    status?: boolean;
}
