export class Booking {
    id?: string;
    userId?: string;
    userName?: string;
    userEmail?: string;
    userProfile?: string;
    artPieceName?: string;
    designName?: string;
    designId?: string;
    size?: string;
    cost?: number;
    specifications?: string;
    revertMessage?: string;
    expectedReturnDate?: Date;
    review?: string;
    finalImage?: string;
    status?: string;
    createdAt?: number;
    postAdded?: boolean;


}
