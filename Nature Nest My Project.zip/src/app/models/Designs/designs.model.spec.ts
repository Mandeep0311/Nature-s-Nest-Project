import { Designs } from './designs.model';

describe('Designs', () => {
  it('should create an instance', () => {
    expect(new Designs()).toBeTruthy();
  });
});
