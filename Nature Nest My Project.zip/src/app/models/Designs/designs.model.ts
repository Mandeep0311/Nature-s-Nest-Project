export class Designs {
    id?: string;
    name?: string;
    artpieceId?: string;
    artPieceName?: string;
    preferredsize?: number;
    imageUrl?: string;
    description?: string;
    createdAt?: number;
    status?: boolean;
}
