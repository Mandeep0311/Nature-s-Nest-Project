export class Postedwork {
    id?: string;
    bookingId?: string;
    userName?: string;
    review?: string;
    finalProductImageUrl?: string;
    cost?: number;
    userProfile?: string;
    createdAt?: number;
    status?: boolean;
}
