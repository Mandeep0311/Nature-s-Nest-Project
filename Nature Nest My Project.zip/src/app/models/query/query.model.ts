export class Query {
    id?: string;
    name?: string;
    email?: string;
    subject?: string;
    message?: string;
    createdAt?: number;
    status?: boolean;
}
