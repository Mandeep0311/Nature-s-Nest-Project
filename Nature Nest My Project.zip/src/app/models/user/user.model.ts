export class User {
    id?: string;
    name?: string;
    email?: string;
    password?: string;
    uid?: string;
    contact?: number;
    imageUrl?: number;
    address?: string;
    createdAt?: Date;
    userType?: number;
    status?: boolean;
}
