import { TestBed } from '@angular/core/testing';

import { ArtpieceService } from './artpiece.service';

describe('ArtpieceService', () => {
  let service: ArtpieceService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ArtpieceService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
