import { Injectable } from '@angular/core';
import { addDoc, collection, collectionData, CollectionReference, doc, docData, DocumentData, Firestore, query, updateDoc, where } from '@angular/fire/firestore';
import { ArtPiece } from '../../models/ArtPiece/art-piece.model';
import { Observable } from 'rxjs';


@Injectable({
  providedIn: 'root'
})
export class ArtpieceService {

  
  private dbPath = '/Artpieces';
  private artPieceRef: CollectionReference<DocumentData>;

  constructor(private db: Firestore) {
    this.artPieceRef = collection(this.db, this.dbPath);
  }

  add(data: ArtPiece) {
    data.status = true
    data.createdAt = Date.now();
    return addDoc(this.artPieceRef, { ...data });
  }

  getAll(): Observable<ArtPiece[]> {
    return collectionData(
      this.artPieceRef,
      { idField: 'id' }
    ) as Observable<ArtPiece[]>;
  }

  getSingle(id: string) {
    return docData(doc(this.artPieceRef, id), { idField: 'id' });
  }

  updateData(id: string, data: any) {
    return updateDoc(doc(this.artPieceRef, id), data);
  }

  viewArtpieces(): Observable<ArtPiece[]> {
    return collectionData(
     query(this.artPieceRef, where('status', '==', true)),
      { idField: 'id' }
    ) as Observable<ArtPiece[]>;
  }

}
