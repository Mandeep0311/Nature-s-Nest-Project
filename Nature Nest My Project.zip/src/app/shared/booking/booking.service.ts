import { Injectable } from '@angular/core';
import { CollectionReference, DocumentData, Firestore, collection, addDoc, doc, updateDoc, collectionData, query, where } from '@angular/fire/firestore';
import { Booking } from '../../models/Booking/booking.model';
import { Observable } from 'rxjs';


@Injectable({
  providedIn: 'root'
})
export class BookingService {



  private dbPath = '/Bookings';
  private bookingRef: CollectionReference<DocumentData>;

  constructor(private db: Firestore) {
    this.bookingRef = collection(this.db, this.dbPath);
  }

  add(data: Booking) {
    data.status = 'Pending'
    data.createdAt = Date.now()
    return addDoc(this.bookingRef, { ...data });
  }


  updateBooking(id: any, data: any) {
    return updateDoc(doc(this.bookingRef, id), data);
  }



  myBookings(): Observable<Booking[]> {
    const userId = sessionStorage.getItem('uid');
    return collectionData(
      query(this.bookingRef, where('userId', '==', userId)),
      { idField: 'id' }
    ) as Observable<Booking[]>;
  }

  getAll(): Observable<Booking[]> {
    return collectionData(
      this.bookingRef,
      { idField: 'id' }
    ) as Observable<Booking[]>;
  }


}
