import { Injectable } from '@angular/core';
import { addDoc, collection, collectionData, CollectionReference, doc, docData, DocumentData, Firestore, query, updateDoc, where } from '@angular/fire/firestore';
import { Observable } from 'rxjs';
import { Designs } from '../../models/Designs/designs.model';


@Injectable({
  providedIn: 'root'
})
export class DesignService {

  private dbPath = '/designs';
  private designRef: CollectionReference<DocumentData>;

  constructor(private db: Firestore) {
    this.designRef = collection(this.db, this.dbPath);
  }

  add(data: Designs) {
    data.status = true
    data.createdAt = Date.now();
    return addDoc(this.designRef, { ...data });
  }

  getAll(): Observable<Designs[]> {
    return collectionData(
      this.designRef,
      { idField: 'id' }
    ) as Observable<Designs[]>;
  }

  getSingle(id: string) {
    return docData(doc(this.designRef, id), { idField: 'id' });
  }

  updateData(id: string, data: any) {
    return updateDoc(doc(this.designRef, id), data);
  }

  getAllByArtpieces(artpieceId: any): Observable<Designs[]> {
    return collectionData(
      query(this.designRef,
        where('status', '==', true),
        where('artpieceId', '==', artpieceId)
      ),
      { idField: 'id' }
    ) as Observable<Designs[]>;
  }


  viewDesigns(): Observable<Designs[]> {
    return collectionData(
      query(this.designRef,
        where('status', '==', true)
      ),
      { idField: 'id' }
    ) as Observable<Designs[]>;
  }



}
