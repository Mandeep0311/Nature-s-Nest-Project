import { Injectable } from '@angular/core';
import { CollectionReference, DocumentData, Firestore, collection, addDoc, collectionData, query, where } from '@angular/fire/firestore';
import { Observable } from 'rxjs';
import { Postedwork } from '../../models/Postedwork/postedwork.model';



@Injectable({
  providedIn: 'root'
})
export class PostService {

  private dbPath = '/Posts';
  private postRef: CollectionReference<DocumentData>;

  constructor(private db: Firestore) {
    this.postRef = collection(this.db, this.dbPath);
  }

  add(data: Postedwork) {
    data.status = true
    data.createdAt = Date.now();
    return addDoc(this.postRef, { ...data });
  }

  getAll(): Observable<Postedwork[]> {
    return collectionData(
      query(this.postRef,
        where('status', '==', true)
      ),
      { idField: 'id' }
    ) as Observable<Postedwork[]>;
  }

}
