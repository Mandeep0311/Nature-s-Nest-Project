export const environment = {
    production: false,
    firebase: {
        apiKey: "AIzaSyDgl8LyhThyGbVOGWHit4lOZEOITUGOp0o",
        authDomain: "w25-naturesnest-ngfire.firebaseapp.com",
        projectId: "w25-naturesnest-ngfire",
        storageBucket: "w25-naturesnest-ngfire.firebasestorage.app",
        messagingSenderId: "830438532171",
        appId: "1:830438532171:web:8e09df88cf56956d58d9ce",
        measurementId: "G-CYFWV9BLYS"
    }
};
